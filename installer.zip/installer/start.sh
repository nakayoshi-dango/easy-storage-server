#!/bin/bash
echo "Iniciando Easy Storage..."
java -jar easy-storage.jar --spring.config.location=application.properties
